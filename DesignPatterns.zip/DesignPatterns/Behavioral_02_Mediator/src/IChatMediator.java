
public interface IChatMediator {
	public void sendMessage(String msg, AbstractUser user);

	void addUser(AbstractUser user);
}
