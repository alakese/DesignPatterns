/**
 * Mediator design pattern is used to provide a centralized communication medium
 * between different objects in a system.
 *
 * Mediator design pattern is very helpful in an enterprise application where
 * multiple objects are interacting with each other. If the objects interact
 * with each other directly, the system components are tightly-coupled with each
 * other that makes maintainability cost higher and not flexible to extend
 * easily. Mediator pattern focuses on provide a mediator between objects for
 * communication and help in implementing lose-coupling between objects.
 *
 * Air traffic controller is a great example of mediator pattern where the
 * airport control room works as a mediator for communication between different
 * flights.
 *
 * The system objects that communicate each other are called Colleagues. Usually
 * we have an interface or abstract class that provides the contract for
 * communication and then we have concrete implementation of mediators.
 *
 * 1-Mediator pattern is useful when the communication logic between objects is
 * complex, we can have a central point of communication that takes care of
 * communication logic.
 * 
 * 2- Java Message Service (JMS) uses Mediator pattern along with Observer
 * pattern to allow applications to subscribe and publish data to other
 * applications.
 * 
 * 3-We should not use mediator pattern just to achieve lose-coupling because if
 * the number of mediators will grow, then it will become hard to maintain them.
 */
public class Application {
	/**
	 * For our example, we will try to implement a chat application where users can
	 * do group chat. Every user will be identified by it’s name and they can send
	 * and receive messages. The message sent by any user should be received by all
	 * the other users in the group.
	 */
	public static void main(String[] args) {
		IChatMediator mediator = new ChatMediatorImpl();
		AbstractUser user1 = new UserImpl(mediator, "Pankaj");
		AbstractUser user2 = new UserImpl(mediator, "Lisa");
		AbstractUser user3 = new UserImpl(mediator, "Saurabh");
		AbstractUser user4 = new UserImpl(mediator, "David");

		mediator.addUser(user1);
		mediator.addUser(user2);
		mediator.addUser(user3);
		mediator.addUser(user4);

		user1.send("Hi All");

	}
}