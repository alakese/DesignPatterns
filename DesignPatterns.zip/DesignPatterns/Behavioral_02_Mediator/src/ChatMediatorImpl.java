import java.util.ArrayList;
import java.util.List;

public class ChatMediatorImpl implements IChatMediator {

	private List<AbstractUser> users;

	public ChatMediatorImpl() {
		this.users = new ArrayList<>();
	}

	@Override
	public void addUser(AbstractUser user) {
		this.users.add(user);
	}

	@Override
	public void sendMessage(String msg, AbstractUser user) {
		for (AbstractUser u : this.users) {
			// message should not be received by the user sending it
			if (u != user) {
				u.receive(msg);
			}
		}
	}
}
