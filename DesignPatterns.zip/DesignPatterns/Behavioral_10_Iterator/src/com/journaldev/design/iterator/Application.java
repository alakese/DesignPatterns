package com.journaldev.design.iterator;

/**
 * Iterator pattern is one of the behavioral pattern and it’s used to provide a
 * standard way to traverse through a group of Objects. Iterator pattern is
 * widely used in Java Collection Framework where Iterator interface provides
 * methods for traversing through a collection.
 *
 * Iterator pattern is not only about traversing through a collection, we can
 * provide different kind of iterators based on our requirements. For example
 * some client programs are only interested in English channels and want to
 * process only them, they don’t want to process other types of channels.
 *
 * Iterator pattern hides the actual implementation of traversal through the
 * collection and client programs just use iterator methods. Notice the inner
 * class implementation of iterator interface so that the implementation can’t
 * be used by any other collection. Same approach is followed by collection
 * classes also and all of them have inner class implementation of Iterator
 * interface.
 */
public class Application {
	public static void main(String[] args) {
		IChannelCollection channels = populateChannels();
		IChannelIterator baseIterator = channels.iterator(ChannelTypeEnum.ALL);
		while (baseIterator.hasNext()) {
			Channel c = baseIterator.next();
			System.out.println(c.toString());
		}
		System.out.println("******");
		// Channel Type Iterator
		IChannelIterator englishIterator = channels.iterator(ChannelTypeEnum.ENGLISH);
		while (englishIterator.hasNext()) {
			Channel c = englishIterator.next();
			System.out.println(c.toString());
		}
	}

	private static IChannelCollection populateChannels() {
		IChannelCollection channels = new ChannelCollectionImpl();
		channels.addChannel(new Channel(98.5, ChannelTypeEnum.ENGLISH));
		channels.addChannel(new Channel(99.5, ChannelTypeEnum.HINDI));
		channels.addChannel(new Channel(100.5, ChannelTypeEnum.FRENCH));
		channels.addChannel(new Channel(101.5, ChannelTypeEnum.ENGLISH));
		channels.addChannel(new Channel(102.5, ChannelTypeEnum.HINDI));
		channels.addChannel(new Channel(103.5, ChannelTypeEnum.FRENCH));
		channels.addChannel(new Channel(104.5, ChannelTypeEnum.ENGLISH));
		channels.addChannel(new Channel(105.5, ChannelTypeEnum.HINDI));
		channels.addChannel(new Channel(106.5, ChannelTypeEnum.FRENCH));
		return channels;
	}
}
