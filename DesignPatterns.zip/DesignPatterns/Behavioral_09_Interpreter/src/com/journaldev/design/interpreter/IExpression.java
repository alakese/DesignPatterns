package com.journaldev.design.interpreter;

public interface IExpression {
	String interpret(InterpreterContext ic);
}
