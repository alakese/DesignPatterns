package com.journaldev.design.interpreter;

/**
 * is used to define a grammatical representation for a language and provides an
 * interpreter to deal with this grammar.
 *
 * The best example of this pattern is java compiler that interprets the java
 * source code into byte code that is understandable by JVM. Google Translator
 * is also an example of interpreter pattern where the input can be in any
 * language and we can get the output interpreted in another language.
 *
 * ---
 *
 * To implement interpreter pattern, we need to create Interpreter context
 * engine that will do the interpretation work.
 *
 * Then we need to create different Expression implementations that will consume
 * the functionalities provided by the interpreter context.
 *
 * Finally we need to create the client that will take the input from user and
 * decide which Expression to use and then generate output for the user.
 * 
 * @formatter:off
 * 
 *          ----------------------------                    -----------------
 *                   IExpression                            InterpreterClient
 *          -----------------------------                   -----------------
 *          interpret(InterpreterContext)                   interpret(String) 
 *          -----------------------------                   -----------------
 *                   /\      /\                                     |
 *                   ||      ||                                     V
 *  ---------------------  ------------------           ---------------------------
 *  IntToBinaryExpression  IntToHexExpression                InterpreterContext
 *  ---------------------  ------------------           ---------------------------
 *  													getBinaryFormat(int):String
 *                                                      getHexFormat(int):String
 * @formatter:on
 */
public class Application {
	public static void main(String args[]) {
		String str1 = "28 in Binary";
		String str2 = "28 in Hexadecimal";

		InterpreterClient ec = new InterpreterClient(new InterpreterContext());
		System.out.println(str1 + "= " + ec.interpret(str1));
		System.out.println(str2 + "= " + ec.interpret(str2));
	}
}