package com.utorialspoint;

public class OrExpression implements IExpression2 {

	private IExpression2 expr1 = null;
	private IExpression2 expr2 = null;

	public OrExpression(IExpression2 expr1, IExpression2 expr2) {
		this.expr1 = expr1;
		this.expr2 = expr2;
	}

	@Override
	public boolean interpret(String context) {
		return expr1.interpret(context) || expr2.interpret(context);
	}
}
