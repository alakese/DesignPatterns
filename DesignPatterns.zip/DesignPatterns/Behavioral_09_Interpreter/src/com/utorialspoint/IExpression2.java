package com.utorialspoint;

public interface IExpression2 {
	public boolean interpret(String context);
}
