package com.utorialspoint;

public class Application {

	public static void main(String[] args) {
		IExpression2 isMale = InterpreterPatternDemo.getMaleExpression();
		System.out.println("John is male? " + isMale.interpret("John"));

		IExpression2 isMarriedWoman = InterpreterPatternDemo.getMarriedWomanExpression();
		System.out.println("Julie is a married women? " + isMarriedWoman.interpret("Married Julie"));
	}
}
