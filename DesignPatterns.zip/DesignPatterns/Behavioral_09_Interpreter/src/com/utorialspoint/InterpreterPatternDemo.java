package com.utorialspoint;

import com.journaldev.design.interpreter.IExpression;

public class InterpreterPatternDemo {
	// Rule: Robert and John are male
	public static IExpression2 getMaleExpression() {
		IExpression2 robert = new TerminalExpression("Robert");
		IExpression2 john = new TerminalExpression("John");
		return (IExpression2) new OrExpression(robert, john);
	}

	// Rule: Julie is a married women
	public static IExpression2 getMarriedWomanExpression() {
		IExpression2 julie = new TerminalExpression("Julie");
		IExpression2 married = new TerminalExpression("Married");
		return new AndExpression(julie, married);
	}

}
