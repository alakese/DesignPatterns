/**
 *
 * Component Implementation
 *
 */
public class BasicCar implements ICar {

	@Override
	public void assemble() {
		System.out.print("Basic Car.");
	}

}
