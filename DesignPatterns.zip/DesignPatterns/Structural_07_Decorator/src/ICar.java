/**
 *
 * Component Interface
 *
 */
public interface ICar {
	public void assemble();
}
