
public interface IPaymentStrategy {
	public void pay(int amount);
}
