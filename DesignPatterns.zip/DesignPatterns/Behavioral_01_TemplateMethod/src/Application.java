/**
 * Template Method is a behavioral design pattern and it’s used to create a
 * method stub and deferring some of the steps of implementation to the
 * subclasses.
 *
 * Template method defines the steps to execute an algorithm and it can provide
 * default implementation that might be common for all or some of the
 * subclasses.
 *
 * Suppose we want to provide an algorithm to build a house. The steps need to
 * be performed to build a house are – building foundation, building pillars,
 * building walls and windows. The important point is that the we can’t change
 * the order of execution because we can’t build windows before building the
 * foundation. So in this case we can create a template method that will use
 * different methods to build the house.
 *
 * 1- Template method should consists of certain steps whose order is fixed and
 * for some of the methods, implementation differs from base class to subclass.
 * Template method should be final.
 * 
 * 2- Most of the times, subclasses calls methods from super class but in
 * template pattern, superclass template method calls methods from subclasses,
 * this is known as Hollywood Principle – “don’t call us, we’ll call you.”.
 * 
 * 3- Methods in base class with default implementation are referred as Hooks
 * and they are intended to be overridden by subclasses, if you want some of the
 * methods to be not overridden, you can make them final, for example in our
 * case we can make buildFoundation() method final because if we don’t want
 * subclasses to override it.
 */
public class Application {

	public static void main(String[] args) {
		AbstractHouseTemplate houseType = new WoodenHouse();
		houseType.buildHouse();

		System.out.println("************");

		houseType = new GlassHouse();
		houseType.buildHouse();
	}

}
