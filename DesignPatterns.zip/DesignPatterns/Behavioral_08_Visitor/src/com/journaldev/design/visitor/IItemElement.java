package com.journaldev.design.visitor;

public interface IItemElement {

	public int accept(IShoppingCartVisitor visitor);
}
