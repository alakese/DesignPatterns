/**
 * producing constant volts of 120V
 */
public class Socket {
	public Volt getVolt() {
		return new Volt(120);
	}
}
