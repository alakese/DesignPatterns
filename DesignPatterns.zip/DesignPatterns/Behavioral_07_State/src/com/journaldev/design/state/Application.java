package com.journaldev.design.state;

/**
 * State design pattern is used when an Object change its behavior based on its
 * internal state.
 *
 * If we have to change the behavior of an object based on its state, we can
 * have a state variable in the Object. Then use if-else condition block to
 * perform different actions based on the state. State design pattern is used to
 * provide a systematic and loosely coupled way to achieve this through Context
 * and State implementations.
 *
 * Context-class: TVContext, State-Implementation: TVStartState and TVStopState
 *
 * State Pattern Context is the class that has a State reference to one of the
 * concrete implementations of the State. Context forwards the request to the
 * state object for processing.
 */
public class Application {

	public static void main(String[] args) {
		TVContext context = new TVContext();
		IState tvStartState = new TVStartState();
		IState tvStopState = new TVStopState();

		context.setState(tvStartState);
		context.doAction();

		context.setState(tvStopState);
		context.doAction();
	}

	/*
	 * Standard implementation
	 *
	 *
	 * package com.journaldev.design.state;
	 *
	 *	public class TVRemoteBasic {
	 *		private String state="";
	 *		public void setState(String state){ 
	 *			this.state=state; 
	 *		}
	 *
	 * 	public void doAction(){
	 *		if(state.equalsIgnoreCase("ON")){
	 *			System.out.println("TV is turned ON");
	 *		}else if(state.equalsIgnoreCase("OFF")){
	 *			System.out.println("TV is turned OFF"); 
	 *		} 
	 *	}
	 *
	 *	public static void main(String args[]){ 
	 *		TVRemoteBasic remote = new TVRemoteBasic();
	 *		remote.setState("ON"); 
	 *		remote.doAction();
	 *		remote.setState("OFF"); 
	 *		remote.doAction(); 
	 *	}
	 * }
	 */

}
