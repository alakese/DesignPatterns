package com.journaldev.design.state;

/**
 * State Design Pattern Concrete Implementation
 */
public class TVStopState implements IState {

	@Override
	public void doAction() {
		System.out.println("TV is turned OFF");
	}

}
