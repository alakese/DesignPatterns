package com.journaldev.design.state;

public interface IState {
	public void doAction();
}
