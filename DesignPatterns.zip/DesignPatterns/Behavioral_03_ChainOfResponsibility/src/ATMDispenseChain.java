
public class ATMDispenseChain {
	private IDispenseChain c1;

	public ATMDispenseChain() {
		// initialize the chain
		this.setC1(new Dollar50Dispenser());
		IDispenseChain c2 = new Dollar20Dispenser();
		IDispenseChain c3 = new Dollar10Dispenser();

		// set the chain of responsibility
		getC1().setNextChain(c2);
		c2.setNextChain(c3);
	}

	/**
	 * @return the c1
	 */
	public IDispenseChain getC1() {
		return c1;
	}

	/**
	 * @param c1 the c1 to set
	 */
	public void setC1(IDispenseChain c1) {
		this.c1 = c1;
	}
}
