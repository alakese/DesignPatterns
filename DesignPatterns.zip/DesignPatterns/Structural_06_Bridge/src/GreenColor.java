
public class GreenColor implements IColor {

	@Override
	public void applyColor() {
		System.out.println("green.");
	}

}
