
public interface IColor {
	public void applyColor();
}
