
public class Pentagon extends AbstractShape {

	public Pentagon(IColor c) {
		super(c);
	}

	@Override
	public void applyColor() {
		System.out.print("Pentagon filled with color ");
		color.applyColor();
	}

}
