package com.journaldev.design.command;

/**
 * IFileSystemReceiver interface defines the contract for the implementation
 * classes.
 */
public interface IFileSystemReceiver {
	void openFile();

	void writeFile();

	void closeFile();
}
