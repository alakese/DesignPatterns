package com.journaldev.design.command;

public interface ICommand {
	void execute();
}
