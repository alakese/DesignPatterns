package com.utorialspoint;

import java.util.ArrayList;
import java.util.List;

public class CareTaker {
	private List<Memento> mementoList = new ArrayList<Memento>();

	public void add2List(Memento state) {
		mementoList.add(state);
	}

	public Memento getFromList(int index) {
		return mementoList.get(index);
	}
}