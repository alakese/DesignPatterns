package com.company.test;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * 3- Composite
 *
 */
public class CompanyDirectory implements IEmployee {
	private List<IEmployee> employeeList = new ArrayList<>();

	@Override
	public void showEmployeeDetails() {
		for (IEmployee emp : employeeList) {
			emp.showEmployeeDetails();
		}
	}

	public void addEmployee(IEmployee emp) {
		employeeList.add(emp);
	}

	public void removeEmployee(IEmployee emp) {
		employeeList.remove(emp);
	}
}
