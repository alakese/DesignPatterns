package com.company.test;

/**
 *
 * 1- Component
 *
 */
public interface IEmployee {
	public void showEmployeeDetails();
}
