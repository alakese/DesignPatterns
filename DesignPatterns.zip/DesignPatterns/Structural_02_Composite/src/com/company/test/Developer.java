package com.company.test;

/**
 *
 * 2- Leaf
 *
 */
public class Developer implements IEmployee {
	private String name;
	private long empId;
	private String position;

	public Developer(long empId, String name, String position) {
		this.empId = empId;
		this.name = name;
		this.position = position;
	}

	@Override
	public void showEmployeeDetails() {
		System.out.println("EmpID:" + empId + ", name:" + name + ", pos:" + position);
	}
}
