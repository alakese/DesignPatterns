public interface IComponent {
	public void add(IComponent c);

	public void remove(IComponent c);

	public void display(int depth);
}
