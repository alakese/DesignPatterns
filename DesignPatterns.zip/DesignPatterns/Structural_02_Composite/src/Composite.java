import java.util.ArrayList;
import java.util.List;

public class Composite implements IComponent {
	private List<IComponent> children = new ArrayList<>();
	private String name;

	public Composite(final String name) {
		this.name = name;
	}

	@Override
	public void add(IComponent c) {
		children.add(c);
	}

	@Override
	public void remove(IComponent c) {
		children.remove(c);
	}

	@Override
	public void display(int depth) {
		for (int i = 0; i < depth; ++i)
			System.out.print("-");
		System.out.println(this.name);
		for (IComponent c : children) {
			c.display(depth + 1);
		}

	}

}
