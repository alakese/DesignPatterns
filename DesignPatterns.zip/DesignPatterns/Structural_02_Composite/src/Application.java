
/**
 * is used when we have to represent a part-whole hierarchy. When we need to
 * create a structure in a way that the objects in the structure has to be
 * treated the same way.
 *
 * Composite Pattern consists of following objects.
 *
 * 1- Component: Component declares the interface for objects in the composition
 * and for accessing and managing its child components. It also implements
 * default behavior for the interface common to all classes as appropriate. It
 * can be an interface or an abstract class with some methods common to all the
 * objects.
 *
 * 2- Leaf: Defines the behavior for primitive objects in the composition. It
 * represents leaf objects in the composition. It doesn’t have references to
 * other Components.
 *
 * 3- Composite: Composite stores child components and implements child related
 * operations in the component interface.
 */
public class Application {

	public static void main(String[] args) {
		// Create a tree structure
		Composite root = new Composite("root");
		root.add(new Leaf("Leaf A"));
		root.add(new Leaf("Leaf B"));

		Composite comp = new Composite("Composite X");
		comp.add(new Leaf("Leaf XA"));
		comp.add(new Leaf("Leaf XB"));

		root.add(comp);
		root.add(new Leaf("Leaf C"));

		// Add and remove a leaf
		Leaf leaf = new Leaf("Leaf D");
		root.add(leaf);
		root.remove(leaf);

		// Recursively display tree
		root.display(1);

	}

}
