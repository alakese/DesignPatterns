
public class Leaf implements IComponent {
	private String name;

	public Leaf(final String name) {
		this.name = name;
	}

	@Override
	public void add(IComponent c) {
		System.out.println("Cannot add to a leaf");
	}

	@Override
	public void remove(IComponent c) {
		System.out.println("Cannot remove from a leaf");
	}

	@Override
	public void display(int depth) {
		for (int i = 0; i < depth; ++i)
			System.out.print("-");
		System.out.println(this.name);
	}

}
